describe('pc.input', function () {
    it("Namespace exists", function () {
        expect(pc.input).to.exist;
    });
});

