Object.assign(pc, function () {
    var SpriteComponentData = function () {
        this.enabled = true;
    };

    return {
        SpriteComponentData: SpriteComponentData
    };
}());
