Object.assign(pc, function () {
    var LayoutChildComponentData = function () {
        this.enabled = true;
    };

    return {
        LayoutChildComponentData: LayoutChildComponentData
    };
}());
