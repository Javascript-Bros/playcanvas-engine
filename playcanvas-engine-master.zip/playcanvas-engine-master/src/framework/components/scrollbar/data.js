Object.assign(pc, function () {
    var ScrollbarComponentData = function () {
        this.enabled = true;
    };

    return {
        ScrollbarComponentData: ScrollbarComponentData
    };
}());
