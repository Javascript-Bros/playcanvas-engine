Object.assign(pc, function () {
    var AudioListenerComponentData = function () {
        // Serialized
        this.enabled = true;
    };

    return {
        AudioListenerComponentData: AudioListenerComponentData
    };
}());
