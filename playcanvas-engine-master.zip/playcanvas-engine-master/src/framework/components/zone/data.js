Object.assign(pc, function () {
    var ZoneComponentData = function () {
        this.enabled = true;
    };

    return {
        ZoneComponentData: ZoneComponentData
    };
}());
