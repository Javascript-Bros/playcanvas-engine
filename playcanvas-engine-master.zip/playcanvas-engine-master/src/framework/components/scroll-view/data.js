Object.assign(pc, function () {
    var ScrollViewComponentData = function () {
        this.enabled = true;
    };

    return {
        ScrollViewComponentData: ScrollViewComponentData
    };
}());
