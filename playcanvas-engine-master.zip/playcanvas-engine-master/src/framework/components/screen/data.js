Object.assign(pc, function () {
    var ScreenComponentData = function () {
        this.enabled = true;
    };

    return {
        ScreenComponentData: ScreenComponentData
    };
}());
