Object.assign(pc, function () {
    var ElementComponentData = function () {
        this.enabled = true;
    };

    return {
        ElementComponentData: ElementComponentData
    };
}());
