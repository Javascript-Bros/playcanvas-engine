Object.assign(pc, function () {
    /**
     * @private
     * @constructor
     * @name pc.ComponentData
     * @classdesc Base class for Component data storage.
     */
    var ComponentData = function () {
    };

    return {
        ComponentData: ComponentData
    };
}());
