Object.assign(pc, function () {
    var ScriptComponentData = function () {
        this.enabled = true;
    };

    return {
        ScriptComponentData: ScriptComponentData
    };
}());
