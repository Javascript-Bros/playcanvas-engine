Object.assign(pc, function () {
    var LayoutGroupComponentData = function () {
        this.enabled = true;
    };

    return {
        LayoutGroupComponentData: LayoutGroupComponentData
    };
}());
