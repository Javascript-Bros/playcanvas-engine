pc.getDefaultMaterial = function () {
    return pc.Application.getApplication().scene.defaultMaterial;
};
